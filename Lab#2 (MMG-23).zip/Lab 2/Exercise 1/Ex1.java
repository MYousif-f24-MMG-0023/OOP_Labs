import java.util.Scanner;
class Ex1{
public static void main(String[]args) {
char const_arr[]={'b', 'c', 'd', 'f', 'g', 'h', 'j',
'k', 'l', 'm', 'n', 'p', 'q', 'r', 's', 't', 'v', 'w', 'x',
'y', 'z' };

 
Scanner consonant=new Scanner (System.in);
System.out.print("Enter the character: ");
char user_inp=consonant.next().charAt(0);
System.out.println(user_inp);
boolean check=false;

for (char cons:const_arr){


if (user_inp==cons){
check=true;
break;
}}
if(check){System.out.println(user_inp + "is a consonant");}

else{  System.out.println(user_inp + " is not a consonant"); } 
}
}