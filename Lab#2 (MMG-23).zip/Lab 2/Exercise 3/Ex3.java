import java.util.Scanner;
class Ex3{
public static void main(String []args){
Scanner input=new Scanner (System.in);
System.out.println("Enter the number of rows: ");
int row=input.nextInt();
System.out.println("Enter the number of col: ");
int col=input.nextInt();

int matrix1[][]=new int [row][col];
int matrix2[][]=new int [row][col];

System.out.println("Types values of first matrix");
for (int i=0; i<row; i++){
	for (int j=0; j<col; j++){
		matrix1[i][j]=input.nextInt();
	}
}


System.out.println("Types values of second matrix");
for (int i=0; i<row; i++){
	for (int j=0; j<col; j++){
		matrix2[i][j]=input.nextInt();
	}
}




System.out.println("---------Output-----------");
for (int i=0; i<row; i++){
	for (int j=0; j<col; j++){
		System.out.println(matrix1[i][j] + matrix2[i][j]);
	}
}	
}
}