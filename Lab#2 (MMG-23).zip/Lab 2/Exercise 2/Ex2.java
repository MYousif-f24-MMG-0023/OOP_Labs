import java.util.Scanner;
class Ex2{
	public static void main (String[]args){
		int array[]=new int[10];
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter 10 integer values");
		for (int i=0; i<array.length; i++){
			array[i]=scanner.nextInt();
		}
		
		int sum=0;
		for (int nums:array){
			if (nums%4==0){
				sum+=nums;
				
			}
		}
		System.out.println("The sum of multiple of 4 is: " +sum);
		
		
	}
}