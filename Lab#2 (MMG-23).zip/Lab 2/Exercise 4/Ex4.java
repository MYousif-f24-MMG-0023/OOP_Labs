import java.util.Scanner;
class Ex4{
	public static void main (String [] args){

	String [] names= new String[6];
	Scanner inp=new Scanner (System.in);
	System.out.println("Enter any six names");
	for (int i=0; i<names.length; i++){
		names[i]=inp.next();
	}
	for  (String name:names){
	
	if (name=="Ali"||name=="ali"){
		System.out.println("Yes, Ali is Present");
			
	}
	else {
		System.out.println("No, Ali is not Present");
	} break;
	} 
	}
}