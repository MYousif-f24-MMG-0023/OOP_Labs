import java.util.Scanner;
class Ex6{
	public static void main (String [] args){
		Scanner inp=new Scanner (System.in);
		System.out.println("Enter your age: ");
		int age=inp.nextInt();
System.out.println((age>=18)? "Yes You are Eligible for voting" : "No You are not eligible for voting");
	}
}