 public class Ex4{
	public static void main(String[]args){
	int [] arr=new int[10];


	int i=0;
	int j=1;



do {
            if (i < 9) {
                arr[i] = j * j; 
            } else {
                arr[i] = 0; 
            }
            j++;
            i++;
        } while (i < arr.length);



        int sumOdd = 0;
        int index = 0;

        while (index < arr.length) {
            if (arr[index] == 81) {
                break;
			}
			 if (arr[index] % 2 != 0) { 
			 sumOdd += arr[index]; 
            }
            index++;

        }
System.out.println("The sum of odd numbers before encountering 81 is: " + sumOdd);







//	int i=0;
//	int j=1;
	
	//	do {
		//	arr[i]=j*j;
		//	j++;
		//	i++;
	//	}
	//	while (i<arr.length);
	//		arr[9]=0;
		
	//	System.out.println(arr[i]);
		
	//	int sum_odd=0;
	//	while (arr[i]%2!=0);{
	//		sum_odd+=arr[i];
	//		System.out.println("Sum of odd numbers" + sum_odd);
	//	}

			
		
	
	
	}
}
