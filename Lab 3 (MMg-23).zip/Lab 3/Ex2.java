import java.util.Scanner;
class Ex2{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		System.out.println("Enter any value, which you think that its a Palindrome: ");
		String pd=input.nextLine();
		//System.out.println(pd.charAt();
		//System.out.println(pd.length());
String rev="";	
	for (int i=pd.length()-1; i>=0; i--){
		rev=rev+pd.charAt(i);
	}
	if (rev.equals(pd)){
		System.out.print(" Yes, it's a Palindrome");
	}
	else {
		System.out.print("No, it's not a Palindrome");
	}
	
	
	}
}
