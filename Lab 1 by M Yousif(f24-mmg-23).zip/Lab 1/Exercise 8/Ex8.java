import java.util.Scanner;
class Ex8{
public static void main(String[] args) 
{
Scanner enterspeed = new Scanner(System.in);
System.out.print("Enter speed in miles per hour: ");
double Milesperhour;
double Kilometersperhour;
Milesperhour = enterspeed.nextDouble();
Kilometersperhour =Milesperhour*1.60934;
System.out.println("Equivalent speed in kilometers per hour: " + Kilometersperhour);
}
}


