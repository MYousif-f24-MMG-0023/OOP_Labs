import java.util.Scanner;
class Ex7{
public static void main(String[] args) {
Scanner enterradiusandheight = new Scanner(System.in);
double radius;
double height;
double volume;

System.out.print("Enter the radius of the cylinder: ");
radius = enterradiusandheight.nextDouble();
System.out.print("\nEnter the height of the cylinder: ");
height = enterradiusandheight.nextDouble();
volume = Math.PI * radius * radius * height;
System.out.println("The volume of the cylinder is: " + volume);
}
}
