class Ex3{
public static void main(String[]args){
String name;
int age;
String studentID;
double cgpa;
String gender;
boolean isForeigner=false;

 name= "M Yousif";
 age = 18;
 studentID = "mmg23";
 cgpa =3.3;
 gender = "Male";


 System.out.println("Student Details: \n");
 System.out.println("Name: " + name);
 System.out.println("Age: " + age);
 System.out.println("Student ID: " + studentID);
 System.out.println("GPA: " + cgpa);
 System.out.println("Gender: " + gender);
 System.out.println("Foreigner: " + (isForeigner ? "Yes" : "No"));


}
}
