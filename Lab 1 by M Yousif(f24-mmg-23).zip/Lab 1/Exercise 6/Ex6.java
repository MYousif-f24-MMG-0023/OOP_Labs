import java.util.Scanner;
class Ex6{
public static void main(String[]args){
Scanner dollarvalue = new Scanner(System.in);
System.out.print("Enter the value in Dollars: ");
double dollars =dollarvalue.nextDouble();
double rupees = dollars*278.67;
System.out.println("Value in Rupees: " + rupees);
}
}



